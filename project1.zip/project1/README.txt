CloudFront endpoint URL : http://drcnvx4rml9yv.cloudfront.net/
s3 url : http://fwd-udacity-project1-bucket.s3-website-us-east-1.amazonaws.com/